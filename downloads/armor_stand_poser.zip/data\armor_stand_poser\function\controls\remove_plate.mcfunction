scoreboard players set @s as_plate 0
execute as @e[type=armor_stand,tag=as_target,limit=1] at @s run function armor_stand_poser:controls/remove_plate_do
