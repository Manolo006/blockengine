execute store result score #angle as_var run data get entity @s Pose.RightArm[0] 1
scoreboard players operation #angle as_var += #delta as_var
function armor_stand_poser:rotate/normalize
execute store result entity @s Pose.RightArm[0] float 1 run scoreboard players get #angle as_var
