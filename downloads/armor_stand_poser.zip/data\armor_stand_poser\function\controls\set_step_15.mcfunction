scoreboard players set #step as_var 15
