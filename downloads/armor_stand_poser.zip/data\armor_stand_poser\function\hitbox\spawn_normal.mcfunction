execute at @s positioned ^0 ^1.4 ^0 run summon interaction ~ ~ ~ {width:0.8f,height:0.65f,response:1b,Tags:["as_hitbox","as_part_0"]}
execute at @s positioned ^0 ^0.75 ^0 run summon interaction ~ ~ ~ {width:0.65f,height:0.65f,response:1b,Tags:["as_hitbox","as_part_1"]}
execute at @s positioned ^-0.38 ^0.75 ^0 run summon interaction ~ ~ ~ {width:0.45f,height:0.75f,response:1b,Tags:["as_hitbox","as_part_2"]}
execute at @s positioned ^0.38 ^0.75 ^0 run summon interaction ~ ~ ~ {width:0.45f,height:0.75f,response:1b,Tags:["as_hitbox","as_part_3"]}
execute at @s positioned ^-0.18 ^0.0 ^0 run summon interaction ~ ~ ~ {width:0.38f,height:0.75f,response:1b,Tags:["as_hitbox","as_part_4"]}
execute at @s positioned ^0.18 ^0.0 ^0 run summon interaction ~ ~ ~ {width:0.38f,height:0.75f,response:1b,Tags:["as_hitbox","as_part_5"]}
