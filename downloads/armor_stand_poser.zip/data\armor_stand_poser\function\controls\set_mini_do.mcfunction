data modify entity @s Small set value 1b
kill @e[type=interaction,tag=as_hitbox]
execute at @s run function armor_stand_poser:hitbox/spawn
playsound minecraft:block.stone_button.click_on player @a ~ ~ ~ 0.5 1.4
tellraw @a[distance=..8] [{"text":"[Armor Stand] ","color":"light_purple","bold":true},{"text":"Dimensione impostata a: Mini!","color":"yellow"}]
