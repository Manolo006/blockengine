execute store result score #angle as_var run data get entity @s Pose.Head[1] 1
scoreboard players operation #angle as_var += #delta as_var
function armor_stand_poser:rotate/normalize
execute store result entity @s Pose.Head[1] float 1 run scoreboard players get #angle as_var
