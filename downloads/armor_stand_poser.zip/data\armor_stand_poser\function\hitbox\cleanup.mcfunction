execute as @e[type=armor_stand,tag=as_target] run data modify entity @s Marker set value 0b
execute as @e[type=armor_stand,tag=as_target] run data modify entity @s DisabledSlots set value 0
execute as @e[type=armor_stand,tag=as_target] run data modify entity @s Invulnerable set value 0b
tag @e[type=armor_stand,tag=as_target] remove as_target
kill @e[type=interaction,tag=as_hitbox]
