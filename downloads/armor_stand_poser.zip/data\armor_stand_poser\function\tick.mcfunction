scoreboard players enable @a as_step
scoreboard players enable @a as_arms
scoreboard players enable @a as_small
scoreboard players enable @a as_mini
scoreboard players enable @a as_plate
scoreboard players enable @a as_reset
scoreboard players enable @a as_menu
scoreboard players enable @a as_axis
scoreboard players enable @a as_part

execute as @a[scores={as_step=1..}] at @s run function armor_stand_poser:controls/handle_step
execute as @a[scores={as_arms=1..}] at @s run function armor_stand_poser:controls/toggle_arms
execute as @a[scores={as_small=1..}] at @s run function armor_stand_poser:controls/set_mini
execute as @a[scores={as_mini=1..}] at @s run function armor_stand_poser:controls/set_mini
execute as @a[scores={as_plate=1..}] at @s run function armor_stand_poser:controls/remove_plate
execute as @a[scores={as_reset=1..}] at @s run function armor_stand_poser:controls/reset_pose
execute as @a[scores={as_menu=1..}] at @s run function armor_stand_poser:controls/show_menu
execute as @a[scores={as_axis=1..}] at @s run function armor_stand_poser:controls/handle_axis
execute as @a[scores={as_part=1..}] at @s run function armor_stand_poser:controls/handle_part

execute as @a[predicate=armor_stand_poser:holding_stick] at @s run function armor_stand_poser:player_tick
execute unless entity @a[predicate=armor_stand_poser:holding_stick] if entity @e[type=interaction,tag=as_hitbox] run function armor_stand_poser:hitbox/cleanup
