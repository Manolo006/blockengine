execute if score #angle as_var matches 360.. run scoreboard players remove #angle as_var 360
execute if score #angle as_var matches ..-1 run scoreboard players add #angle as_var 360
