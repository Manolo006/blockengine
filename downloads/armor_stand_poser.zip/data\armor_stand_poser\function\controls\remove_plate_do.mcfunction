data modify entity @s NoBasePlate set value 1b
playsound minecraft:block.stone_button.click_on player @a ~ ~ ~ 0.5 1.4
tellraw @a[distance=..8] [{"text":"[Armor Stand] ","color":"light_purple","bold":true},{"text":"Pedana di base rimossa!","color":"yellow"}]
