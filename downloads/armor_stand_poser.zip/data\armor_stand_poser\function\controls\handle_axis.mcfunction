execute if score @s as_axis matches 1 run scoreboard players set #axis as_var 0
execute if score @s as_axis matches 2 run scoreboard players set #axis as_var 1
execute if score @s as_axis matches 3 run scoreboard players set #axis as_var 2
scoreboard players set @s as_axis 0
playsound minecraft:ui.button.click player @s ~ ~ ~ 0.5 1.5
function armor_stand_poser:actionbar/show_axis_change
