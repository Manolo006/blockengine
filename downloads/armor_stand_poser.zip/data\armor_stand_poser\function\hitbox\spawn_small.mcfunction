execute at @s positioned ^0 ^0.7 ^0 run summon interaction ~ ~ ~ {width:0.45f,height:0.35f,response:1b,Tags:["as_hitbox","as_part_0"]}
execute at @s positioned ^0 ^0.37 ^0 run summon interaction ~ ~ ~ {width:0.35f,height:0.35f,response:1b,Tags:["as_hitbox","as_part_1"]}
execute at @s positioned ^-0.2 ^0.37 ^0 run summon interaction ~ ~ ~ {width:0.25f,height:0.35f,response:1b,Tags:["as_hitbox","as_part_2"]}
execute at @s positioned ^0.2 ^0.37 ^0 run summon interaction ~ ~ ~ {width:0.25f,height:0.35f,response:1b,Tags:["as_hitbox","as_part_3"]}
execute at @s positioned ^-0.1 ^0.0 ^0 run summon interaction ~ ~ ~ {width:0.22f,height:0.37f,response:1b,Tags:["as_hitbox","as_part_4"]}
execute at @s positioned ^0.1 ^0.0 ^0 run summon interaction ~ ~ ~ {width:0.22f,height:0.37f,response:1b,Tags:["as_hitbox","as_part_5"]}
