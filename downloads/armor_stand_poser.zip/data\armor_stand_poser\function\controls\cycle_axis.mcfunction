scoreboard players add #axis as_var 1
execute if score #axis as_var matches 3.. run scoreboard players set #axis as_var 0

playsound minecraft:ui.button.click player @s ~ ~ ~ 0.5 1.5

function armor_stand_poser:actionbar/show_axis_change
