execute if score #part as_var matches 2..3 run data modify entity @s ShowArms set value 1b

execute if score #part as_var matches 0 run function armor_stand_poser:rotate/head
execute if score #part as_var matches 1 run function armor_stand_poser:rotate/body
execute if score #part as_var matches 2 run function armor_stand_poser:rotate/right_arm
execute if score #part as_var matches 3 run function armor_stand_poser:rotate/left_arm
execute if score #part as_var matches 4 run function armor_stand_poser:rotate/right_leg
execute if score #part as_var matches 5 run function armor_stand_poser:rotate/left_leg
execute if score #part as_var matches 6 run function armor_stand_poser:rotate/stand_yaw

playsound minecraft:entity.item_frame.rotate_item player @a ~ ~ ~ 0.5 1.3
particle minecraft:dust{color:[0.7f,0.3f,1.0f],scale:0.7f} ~ ~1 ~ 0.1 0.2 0.1 0 4
