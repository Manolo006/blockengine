scoreboard objectives add as_use minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add as_sneak minecraft.custom:minecraft.sneak_time
scoreboard objectives add as_var dummy
scoreboard objectives add as_step trigger
scoreboard objectives add as_arms trigger
scoreboard objectives add as_small trigger
scoreboard objectives add as_mini trigger
scoreboard objectives add as_plate trigger
scoreboard objectives add as_reset trigger
scoreboard objectives add as_menu trigger
scoreboard objectives add as_axis trigger
scoreboard objectives add as_part trigger

scoreboard players set #-1 as_var -1
scoreboard players set #step as_var 15
execute unless score #part as_var matches 0.. run scoreboard players set #part as_var 0
execute unless score #axis as_var matches 0.. run scoreboard players set #axis as_var 0

scoreboard players enable @a as_step
scoreboard players enable @a as_arms
scoreboard players enable @a as_small
scoreboard players enable @a as_mini
scoreboard players enable @a as_plate
scoreboard players enable @a as_reset
scoreboard players enable @a as_menu
scoreboard players enable @a as_axis
scoreboard players enable @a as_part

# UNLOCK ALL ARMOR STANDS IN THE WORLD COMPLETELY:
execute as @e[type=armor_stand] run data modify entity @s Marker set value 0b
execute as @e[type=armor_stand] run data modify entity @s DisabledSlots set value 0
execute as @e[type=armor_stand] run data modify entity @s Invulnerable set value 0b
tag @e[type=armor_stand] remove as_target
kill @e[type=interaction,tag=as_hitbox]

tellraw @a ["",{"text":"\n[Armor Stand Poser] ","color":"light_purple","bold":true},{"text":"Datapack caricato con successo! Tutti gli Armor Stand sono sbloccati.\n","color":"green"},{"text":"• Clicca ","color":"gray"},{"text":"[QUI PER OTTENERE IL POSER STICK]","color":"gold","bold":true,"underlined":true,"click_event":{"action":"run_command","command":"/function armor_stand_poser:give"},"hover_event":{"action":"show_text","value":{"text":"Ottieni lo stick di modifica!","color":"yellow"}}},{"text":" oppure digita ","color":"gray"},{"text":"/function armor_stand_poser:give\n","color":"aqua"}]
