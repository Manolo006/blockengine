execute if score #axis as_var matches 0 run function armor_stand_poser:actionbar/show_rot_x
execute if score #axis as_var matches 1 run function armor_stand_poser:actionbar/show_rot_y
execute if score #axis as_var matches 2 run function armor_stand_poser:actionbar/show_rot_z
