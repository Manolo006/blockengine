scoreboard players set @s as_small 0
scoreboard players set @s as_mini 0
execute as @e[type=armor_stand,tag=as_target,limit=1] at @s run function armor_stand_poser:controls/set_mini_do
