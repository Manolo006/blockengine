execute unless data entity @s Pose.LeftArm run data modify entity @s Pose.LeftArm set value [0.0f,0.0f,0.0f]
execute if score #axis as_var matches 0 run function armor_stand_poser:rotate/left_arm_x
execute if score #axis as_var matches 1 run function armor_stand_poser:rotate/left_arm_y
execute if score #axis as_var matches 2 run function armor_stand_poser:rotate/left_arm_z
