advancement revoke @s only armor_stand_poser:craft_stick

clear @s minecraft:stick 1

execute as @e[type=armor_stand,distance=..4] if items entity @s weapon.mainhand minecraft:stick run item replace entity @s weapon.mainhand with air

give @s warped_fungus_on_a_stick[custom_data={armor_stand_poser:1b},item_name={text:"Armor Stand Poser Stick",color:"light_purple",bold:true},item_model="minecraft:debug_stick",lore=[{text:"Tasto Destro: Ruota elemento (+15°)",color:"yellow"},{text:"Tasto Sinistro: Cambia Asse (X -> Y -> Z)",color:"aqua"},{text:"Shift + Tasto Destro: Ruota indietro (-15°)",color:"gold"},{text:"Clicca direttamente sulle parti dell'Armor Stand!",color:"gray",italic:true}]] 1

playsound minecraft:block.amethyst_block.chime player @a ~ ~ ~ 1.0 1.2
playsound minecraft:block.enchantment_table.use player @a ~ ~ ~ 0.8 1.5
particle minecraft:dust{color:[0.9f,0.4f,1.0f],scale:1.2f} ~ ~1 ~ 0.3 0.5 0.3 0 15

title @s actionbar [{"text":"[Poser] ","color":"light_purple","bold":true},{"text":"Bastoncino sintonizzato con successo!","color":"green","bold":true}]
tellraw @s [{"text":"[Armor Stand Poser] ","color":"light_purple","bold":true},{"text":"Il tuo bastoncino è diventato un ","color":"gray"},{"text":"Poser Stick","color":"gold","bold":true},{"text":"! Ora puoi iniziare a posare l'Armor Stand.","color":"gray"}]
