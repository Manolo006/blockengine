execute unless data entity @s Pose.RightLeg run data modify entity @s Pose.RightLeg set value [0.0f,0.0f,0.0f]
execute if score #axis as_var matches 0 run function armor_stand_poser:rotate/right_leg_x
execute if score #axis as_var matches 1 run function armor_stand_poser:rotate/right_leg_y
execute if score #axis as_var matches 2 run function armor_stand_poser:rotate/right_leg_z
