data modify entity @s Pose.Head set value [0.0f,0.0f,0.0f]
data modify entity @s Pose.Body set value [0.0f,0.0f,0.0f]
data modify entity @s Pose.RightArm set value [0.0f,0.0f,0.0f]
data modify entity @s Pose.LeftArm set value [0.0f,0.0f,0.0f]
data modify entity @s Pose.RightLeg set value [0.0f,0.0f,0.0f]
data modify entity @s Pose.LeftLeg set value [0.0f,0.0f,0.0f]
data modify entity @s Small set value 0b
data modify entity @s NoBasePlate set value 0b
kill @e[type=interaction,tag=as_hitbox]
execute at @s run function armor_stand_poser:hitbox/spawn
playsound minecraft:block.anvil.land player @a ~ ~ ~ 0.5 1.6
tellraw @a[distance=..8] [{"text":"[Armor Stand] ","color":"light_purple","bold":true},{"text":"Posa resettata alla posizione neutra!","color":"green"}]
