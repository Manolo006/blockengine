execute store result score #angle as_var run data get entity @s Rotation[0] 1
scoreboard players operation #angle as_var += #delta as_var
function armor_stand_poser:rotate/normalize
execute store result entity @s Rotation[0] float 1 run scoreboard players get #angle as_var
kill @e[type=interaction,tag=as_hitbox]
execute at @s run function armor_stand_poser:hitbox/spawn
