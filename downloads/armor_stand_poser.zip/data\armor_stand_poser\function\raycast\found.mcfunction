scoreboard players set #found_target as_var 1
execute as @e[type=armor_stand,distance=..0.8,limit=1,sort=nearest] unless entity @s[tag=as_target] run function armor_stand_poser:hitbox/set_target
