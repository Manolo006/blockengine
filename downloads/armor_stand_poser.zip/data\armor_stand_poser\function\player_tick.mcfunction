function armor_stand_poser:select_stand

execute as @e[type=interaction,tag=as_hitbox] if data entity @s attack run function armor_stand_poser:hitbox/on_attack
execute as @e[type=interaction,tag=as_hitbox] if data entity @s interaction run function armor_stand_poser:hitbox/on_interact

execute if score @s as_use matches 1.. run function armor_stand_poser:controls/right_click

scoreboard players set @s as_use 0
scoreboard players set @s as_sneak 0
