scoreboard players add #ray_dist as_var 1

execute if entity @e[type=armor_stand,distance=..0.8] run function armor_stand_poser:raycast/found

execute if score #found_target as_var matches 0 if score #ray_dist as_var matches ..11 positioned ^ ^ ^0.4 run function armor_stand_poser:raycast/step
