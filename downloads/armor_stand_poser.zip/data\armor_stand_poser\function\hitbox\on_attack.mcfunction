execute if entity @s[tag=as_part_0] run scoreboard players set #clicked_part as_var 0
execute if entity @s[tag=as_part_1] run scoreboard players set #clicked_part as_var 1
execute if entity @s[tag=as_part_2] run scoreboard players set #clicked_part as_var 2
execute if entity @s[tag=as_part_3] run scoreboard players set #clicked_part as_var 3
execute if entity @s[tag=as_part_4] run scoreboard players set #clicked_part as_var 4
execute if entity @s[tag=as_part_5] run scoreboard players set #clicked_part as_var 5

execute on attacker run function armor_stand_poser:hitbox/handle_attack

data remove entity @s attack
