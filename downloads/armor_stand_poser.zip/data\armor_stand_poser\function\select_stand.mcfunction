execute as @e[type=armor_stand,tag=as_target] at @s unless entity @p[distance=..6,predicate=armor_stand_poser:holding_stick] run function armor_stand_poser:hitbox/cleanup

scoreboard players set #ray_dist as_var 0
scoreboard players set #found_target as_var 0
execute anchored eyes positioned ^ ^ ^0.4 run function armor_stand_poser:raycast/step

execute if score #found_target as_var matches 0 unless entity @e[type=armor_stand,tag=as_target,distance=..6] run function armor_stand_poser:hitbox/cleanup
