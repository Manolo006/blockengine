execute store result score #step as_var run scoreboard players get @s as_step
execute if score #step as_var matches ..0 run scoreboard players set #step as_var 15
execute if score #step as_var matches 361.. run scoreboard players set #step as_var 15
scoreboard players set @s as_step 0
playsound minecraft:block.note_block.pling player @s ~ ~ ~ 0.6 1.8
tellraw @s [{"text":"[Armor Stand Poser] ","color":"light_purple","bold":true},{"text":"Passo di rotazione impostato a: ","color":"gray"},{"score":{"name":"#step","objective":"as_var"},"color":"gold","bold":true},{"text":"°","color":"gold"}]
