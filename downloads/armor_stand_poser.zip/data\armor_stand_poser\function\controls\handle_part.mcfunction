execute if score @s as_part matches 1 run scoreboard players set #part as_var 0
execute if score @s as_part matches 2 run scoreboard players set #part as_var 1
execute if score @s as_part matches 3 run scoreboard players set #part as_var 2
execute if score @s as_part matches 4 run scoreboard players set #part as_var 3
execute if score @s as_part matches 5 run scoreboard players set #part as_var 4
execute if score @s as_part matches 6 run scoreboard players set #part as_var 5
execute if score @s as_part matches 7 run scoreboard players set #part as_var 6
scoreboard players set @s as_part 0
playsound minecraft:ui.button.click player @s ~ ~ ~ 0.5 1.5
tellraw @s [{"text":"[Armor Stand Poser] ","color":"light_purple","bold":true},{"text":"Parte selezionata per la rotazione!","color":"green"}]
