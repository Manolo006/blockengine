execute if score #step as_var matches 15 run function armor_stand_poser:controls/set_step_45
execute if score #step as_var matches 45 run function armor_stand_poser:controls/set_step_90
execute if score #step as_var matches 90 run function armor_stand_poser:controls/set_step_1
execute if score #step as_var matches 1 run function armor_stand_poser:controls/set_step_5
execute if score #step as_var matches 5 run function armor_stand_poser:controls/set_step_15

scoreboard players set @s as_step 0

playsound minecraft:block.note_block.pling player @s ~ ~ ~ 0.6 1.8
tellraw @s [{"text":"[Armor Stand Poser] ","color":"light_purple","bold":true},{"text":"Passo di rotazione impostato a: ","color":"gray"},{"score":{"name":"#step","objective":"as_var"},"color":"gold","bold":true},{"text":"°","color":"gold"}]
