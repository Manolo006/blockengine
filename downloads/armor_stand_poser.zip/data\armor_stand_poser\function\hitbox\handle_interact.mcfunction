scoreboard players operation #part as_var = #clicked_part as_var
scoreboard players set @s as_use 0
function armor_stand_poser:controls/right_click
