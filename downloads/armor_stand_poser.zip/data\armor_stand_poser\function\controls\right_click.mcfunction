scoreboard players operation #delta as_var = #step as_var
execute if predicate armor_stand_poser:is_sneaking run scoreboard players operation #delta as_var *= #-1 as_var

execute as @e[type=armor_stand,tag=as_target,limit=1] at @s run function armor_stand_poser:rotate/apply

function armor_stand_poser:actionbar/show_rotation
