tag @e[type=armor_stand,tag=as_target] remove as_target
kill @e[type=interaction,tag=as_hitbox]

tag @s add as_target

particle minecraft:dust{color:[0.8f,0.2f,1.0f],scale:0.8f} ~ ~0.1 ~ 0.2 0.05 0.2 0 10

execute at @s run function armor_stand_poser:hitbox/spawn
