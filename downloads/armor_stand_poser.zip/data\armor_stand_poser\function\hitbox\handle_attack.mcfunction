scoreboard players operation #part as_var = #clicked_part as_var
function armor_stand_poser:controls/cycle_axis
