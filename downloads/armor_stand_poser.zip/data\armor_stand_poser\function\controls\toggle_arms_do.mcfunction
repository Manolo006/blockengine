execute if data entity @s {ShowArms:1b} run tag @s add as_had_arms
execute if entity @s[tag=as_had_arms] run data modify entity @s ShowArms set value 0b
execute unless entity @s[tag=as_had_arms] run data modify entity @s ShowArms set value 1b
tag @s remove as_had_arms
playsound minecraft:block.stone_button.click_on player @a ~ ~ ~ 0.5 1.4
tellraw @a[distance=..8] [{"text":"[Armor Stand] ","color":"light_purple","bold":true},{"text":"Mostra Braccia: Invertito!","color":"yellow"}]
