execute unless data entity @s Pose.LeftLeg run data modify entity @s Pose.LeftLeg set value [0.0f,0.0f,0.0f]
execute if score #axis as_var matches 0 run function armor_stand_poser:rotate/left_leg_x
execute if score #axis as_var matches 1 run function armor_stand_poser:rotate/left_leg_y
execute if score #axis as_var matches 2 run function armor_stand_poser:rotate/left_leg_z
