### Clocks
# Game Clock
execute if score start uhc.trigger matches 1 run function uhc:game_clock

# Before Clock
execute if score start uhc.trigger matches 0 run function uhc:pre_game_clock

# no pvp
function uhc:nopvp

# spect dopo la morte
execute as @a[scores={uhc.deathCount=1..}] run gamemode spectator @s[gamemode=survival]
team leave @a[scores={uhc.deathCount=1..}]
scoreboard players set @a[scores={uhc.deathCount=1..}] uhc.deathCount 2