# 2 Lines of Hearts Function
execute as @a run attribute @s minecraft:max_health base set 40
effect give @a minecraft:regeneration 5 255 true