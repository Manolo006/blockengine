# World Border Display
execute as @a[tag=!global.ignore.gui,tag=!global.ignore,scores={uhc.wb.display=1}] at @s run title @s actionbar ["",{"text":"Dimensione Bordo: ","color":"gold"},{"score":{"name":"wbSize","objective":"uhc.trigger"},"color":"white"},{"text":"x","color":"white"},{"score":{"name":"wbSize","objective":"uhc.trigger"}},{"text": "   player vivi: ","color": "gold"},{"score":{"name": "AlivePlayers","objective": "uhc.info"}},{"text": "    Kills: ","color": "gold"},{"score":{"name": "@s","objective": "kills"}}]




execute as @a[scores={uhc.c.killCount=1..,},team=uhc.aqua] run scoreboard players operation killgroupAqua uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.green] run scoreboard players operation killgroupGreen uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.blue] run scoreboard players operation killgroupBlue uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.lightPurple] run scoreboard players operation killgroupLightPurple uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.gold] run scoreboard players operation killgroupGold uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.red] run scoreboard players operation killgroupRed uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.yellow] run scoreboard players operation killgroupYellow uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.darkAqua] run scoreboard players operation killgroupDarkAqua uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.darkBlue] run scoreboard players operation killgroupDarkBlue uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.darkGray] run scoreboard players operation killgroupDarkGray uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.darkGreen] run scoreboard players operation killgroupDarkGreen uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.darkPurple] run scoreboard players operation killgroupDarkPurple uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.darkRed] run scoreboard players operation killgroupDarkRed uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.gray] run scoreboard players operation killgroupGray uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.black] run scoreboard players operation killgroupBlack uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..,},team=uhc.white] run scoreboard players operation killgroupWhite uhc.info += @s uhc.c.killCount
execute as @a[scores={uhc.c.killCount=1..}] run scoreboard players add @s kills 1
scoreboard players set @a uhc.c.killCount 0
