team leave @a
scoreboard players set @a uhc.deathCount 0
schedule function uhc:setup 10s