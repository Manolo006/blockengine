### Scoreboard Resets
scoreboard players set @a uhc.deathCount 0
scoreboard players set @a uhc.c.killCount 0

### Player Prep
difficulty easy
effect clear @a
clear @a
xp set @a 0 points
xp set @a 0 levels
advancement revoke @a everything
gamemode survival @a
gamerule fallDamage true
gamerule drowningDamage true
gamerule locatorBar false
execute if score more_hearts uhc.trigger matches 1 run function uhc:more_hearts
effect give @a saturation 1 100 true
effect give @a regeneration 1 255 true
give @a cooked_beef 32

### Team Selection
function uhc:team_selection


### Selections Display
function uhc:selections

### Hastey Gamemode
execute if score hastey uhc.trigger matches 1 run give @a minecraft:stone_sword
execute if score hastey uhc.trigger matches 1 run give @a minecraft:stone_pickaxe[enchantments={"minecraft:efficiency":3,"minecraft:unbreaking":1}] 1
execute if score hastey uhc.trigger matches 1 run give @a minecraft:stone_axe[enchantments={"minecraft:efficiency":3,"minecraft:unbreaking":1}] 1
execute if score hastey uhc.trigger matches 1 run give @a minecraft:stone_shovel[enchantments={"minecraft:efficiency":3,"minecraft:unbreaking":1}] 1

### Clocks
scoreboard players set start uhc.trigger 1

### World Prep
execute if score wb_shrinking uhc.trigger matches 1 if score wb_1k uhc.trigger matches 1 run function wb:shrinking/wb_shrinking_1k
execute if score wb_shrinking uhc.trigger matches 1 if score wb_3k uhc.trigger matches 1 run function wb:shrinking/wb_shrinking_3k

### Time
gamerule doDaylightCycle true
time set 0

### spawn remove 
fill -9 255 11 9 226 -7 air
execute as @e[tag=uhc.armor_stand.gabbia] at @a run kill @e[type=item,distance=..50]
kill @e[tag=uhc.armor_stand.gabbia]