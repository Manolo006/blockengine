execute as @e[team=drop] at @s unless block ~ ~-1 ~ #minecraft:air run kill @s
execute as @e[team=drop] at @s unless block ~ ~-1 ~ #minecraft:air run stopsound @a master minecraft:entity.generic.explode
execute as @e[team=drop] at @s run particle minecraft:flame ~ ~4 ~ 0.1 1 0.1 0.1 5 force
execute as @e[team=drop] at @s run particle explosion ~ ~2.3 ~ 0.5 0.5 0.5 0.1 1 force