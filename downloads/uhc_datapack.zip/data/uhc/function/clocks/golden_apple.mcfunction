# Golden Apple Drops on Death
execute as @a[scores={uhc.c.killCount=1}] run give @p player_head[consumable={consume_seconds:0.1,has_consume_particles:true,on_consume_effects:[{type:"minecraft:apply_effects",effects:[{id:"minecraft:dolphins_grace",amplifier:3,duration:600,show_particles:1b,show_icon:1b},{id:"minecraft:fire_resistance",amplifier:1,duration:2400,show_particles:1b,show_icon:1b},{id:"minecraft:regeneration",amplifier:3,duration:60,show_particles:1b,show_icon:1b},{id:"minecraft:conduit_power",amplifier:4,duration:600,show_particles:1b,show_icon:1b},{id:"minecraft:resistance",amplifier:2,duration:2400,show_particles:1b,show_icon:1b}]},{type:"minecraft:play_sound",sound:"block.anvil.hit"}]},item_name={"bold":true,"color":"gold","text":"Golden Head"},profile={id:[I;1713795241,400770548,-1316497938,-1316920201],properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDZlYjE3Yzk0NTQ5ZTdiNDg0ODQxM2ZmNzYxYjBhYTk0NTczYjgwNzc3OGQ1ODA3MGE0OTQ1NzEzZWYzNDhkMyJ9fX0="}]}] 1
execute as @a[gamemode=survival] if items entity @s weapon.mainhand minecraft:player_head run gamemode adventure @s
execute as @a[gamemode=adventure] unless items entity @s weapon.mainhand minecraft:player_head run gamemode survival @s



