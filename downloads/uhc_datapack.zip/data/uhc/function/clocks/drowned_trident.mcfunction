# Drowned Trident
execute at @a[scores={uhc.c.drownedK=1..}] run summon minecraft:item ~ ~0.0001 ~ {Item:{id:"minecraft:trident",count:1}}
scoreboard players set @a uhc.c.drownedK 0