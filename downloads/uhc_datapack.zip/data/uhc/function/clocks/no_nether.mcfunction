# Destroys Portal Block
execute at @a if block ~ ~ ~ minecraft:nether_portal run setblock ~ ~ ~ minecraft:air