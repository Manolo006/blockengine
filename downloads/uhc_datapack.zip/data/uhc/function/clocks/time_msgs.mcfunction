# Start & End of Day Messages
execute store result score time uhc.trigger run time query daytime
execute if score uhc.time uhc.trigger matches 1000 run tellraw @a {"text":"It is now daytime.","color":"blue"}
execute if score uhc.time uhc.trigger matches 13000 run tellraw @a {"text":"It is now nightime.","color":"blue"}