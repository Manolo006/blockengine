# 11 floor
fill -7 238 -5 7 238 9 dirt
fill 2 238 9 7 238 9 air
fill 7 238 5 7 238 8 air
fill 5 238 8 6 238 8 air
setblock 6 238 7 minecraft:air
fill 7 238 -1 7 238 -5 air
fill 6 238 -5 6 238 -2 air
fill 3 238 -5 5 238 -5 air
setblock 5 238 -4 minecraft:air
fill -7 238 6 -7 238 9 air
fill -3 238 9 -6 238 9 air
fill -7 238 -5 -1 238 -6 air
fill -2 238 -4 -7 238 -4 air
fill -7 238 0 -7 238 -3 air
fill -6 238 -3 -5 238 -3 air
setblock -6 238 -2 minecraft:air
setblock -7 238 5 minecraft:air
fill -6 238 7 -6 238 8 air
setblock -5 238 8 minecraft:air
setblock -2 238 2 minecraft:rooted_dirt
setblock -3 238 2 minecraft:coarse_dirt
setblock -2 238 3 minecraft:coarse_dirt

# 12 floor
fill -7 239 -5 7 239 9 dirt
fill 4 239 9 7 239 9 air
fill 7 239 6 7 239 8 air
setblock 6 239 8 minecraft:air
fill 4 239 -5 7 239 -5 air
fill 7 239 -2 7 239 -4 air
setblock 6 239 -4 minecraft:air
fill -7 239 -2 -7 239 -5 air
fill -3 239 -5 -6 239 -5 air
fill -5 239 -4 -6 239 -4 air
setblock -6 239 -3 minecraft:air
fill -7 239 6 -7 239 9 air
fill -4 239 9 -6 239 9 air
setblock -6 239 8 minecraft:air
setblock -1 239 9 minecraft:shroomlight
setblock -5 239 3 minecraft:rooted_dirt
setblock -4 239 3 minecraft:coarse_dirt
setblock -5 239 2 minecraft:rooted_dirt
setblock -4 239 1 minecraft:rooted_dirt
fill -2 239 1 -2 239 0 minecraft:coarse_dirt
setblock -1 239 3 minecraft:shroomlight
fill -1 239 5 -2 239 4 minecraft:rooted_dirt
setblock 0 239 3 minecraft:rooted_dirt
setblock 0 239 6 minecraft:rooted_dirt
setblock -3 239 5 minecraft:coarse_dirt
fill 1 239 -2 -1 239 0 minecraft:rooted_dirt
setblock 2 239 -3 minecraft:coarse_dirt

# 13 floor
fill 0 240 -5 -2 240 -5 minecraft:grass_block[snowy=false]
setblock 0 240 -4 minecraft:dirt_path
setblock -1 240 -4 minecraft:coarse_dirt
setblock -2 240 -4 minecraft:dirt_path
setblock -3 240 -4 minecraft:podzol[snowy=false]
setblock -4 240 -4 minecraft:podzol[snowy=false]
setblock -4 240 -3 minecraft:podzol[snowy=false]
setblock -3 240 -3 minecraft:rooted_dirt
setblock -2 240 -3 minecraft:rooted_dirt
setblock -3 240 -2 minecraft:rooted_dirt
setblock -3 240 -2 minecraft:rooted_dirt
setblock -2 240 -2 minecraft:grass_block[snowy=false]
setblock -1 240 -2 minecraft:podzol[snowy=false]
setblock -2 240 -1 minecraft:rooted_dirt
setblock -3 240 -1 minecraft:grass_block[snowy=false]
setblock -4 240 -1 minecraft:rooted_dirt
setblock -5 240 0 minecraft:grass_block[snowy=false]
fill -4 240 0 -3 240 0 minecraft:podzol[snowy=false]
setblock -4 240 1 minecraft:coarse_dirt
setblock -5 240 1 minecraft:shroomlight
setblock -6 240 1 minecraft:podzol[snowy=false]
setblock -7 240 1 minecraft:podzol[snowy=false]
setblock -7 240 0 minecraft:grass_block[snowy=false]
setblock -7 240 -1 minecraft:grass_block[snowy=false]
setblock -6 240 -2 minecraft:rooted_dirt
setblock -5 240 -3 minecraft:rooted_dirt
fill -5 240 -2 -4 240 -2 minecraft:grass_block[snowy=false]
setblock -5 240 -1 minecraft:podzol[snowy=false]
setblock -6 240 -1 minecraft:podzol[snowy=false]
setblock -6 240 0 minecraft:grass_block[snowy=false]
setblock -7 240 2 minecraft:grass_block[snowy=false]
fill -7 240 3 -6 240 6 minecraft:rooted_dirt
setblock -6 240 4 minecraft:dirt_path
setblock -7 240 5 minecraft:podzol[snowy=false]
setblock -7 240 6 minecraft:grass_block[snowy=false]
setblock -6 240 7 minecraft:grass_block[snowy=false]
setblock -7 240 7 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock -6 240 8 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -5 240 9 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -5 240 2 minecraft:grass_block[snowy=false]
setblock -6 240 2 minecraft:coarse_dirt
fill -5 240 4 -4 240 5 minecraft:grass_block[snowy=false]
setblock -4 240 5 minecraft:shroomlight
setblock -4 240 6 minecraft:coarse_dirt
setblock -3 240 6 minecraft:grass_block[snowy=false]
setblock -2 240 6 minecraft:rooted_dirt
setblock -2 240 5 minecraft:grass_block[snowy=false]
setblock -2 240 7 minecraft:grass_block[snowy=false]
setblock -2 240 8 minecraft:shroomlight
setblock -2 240 9 minecraft:grass_block[snowy=false]
setblock -1 240 8 minecraft:rooted_dirt
fill -1 240 9 0 240 9 minecraft:podzol[snowy=false]
setblock -1 240 7 minecraft:grass_block[snowy=false]
fill -3 240 9 -4 240 8 minecraft:podzol
setblock -4 240 8 minecraft:grass_block[snowy=false]
setblock -4 240 7 minecraft:rooted_dirt
setblock -3 240 7 minecraft:coarse_dirt
setblock -5 240 8 minecraft:rooted_dirt
setblock -5 240 7 minecraft:podzol[snowy=false]
setblock -5 240 6 minecraft:podzol[snowy=false]
setblock -1 240 2 minecraft:grass_block[snowy=false]
setblock -1 240 1 minecraft:rooted_dirt
setblock 0 240 1 minecraft:shroomlight
setblock 0 240 0 minecraft:rooted_dirt
setblock 1 240 -1 minecraft:rooted_dirt
setblock 2 240 -2 minecraft:grass_block[snowy=false]
setblock 3 240 -2 minecraft:grass_block[snowy=false]
setblock 3 240 -3 minecraft:coarse_dirt
setblock 2 240 -4 minecraft:grass_block[snowy=false]
setblock 4 240 -3 minecraft:shroomlight
setblock 4 240 -2 minecraft:rooted_dirt
setblock 5 240 -2 minecraft:podzol[snowy=false]
setblock 6 240 -2 minecraft:rooted_dirt
fill 2 240 -5 4 240 -5 minecraft:grass_block
fill 5 240 -3 6 240 -4 minecraft:grass_block
setblock 6 240 -4 minecraft:air
setblock 3 240 -4 minecraft:rooted_dirt
setblock 4 240 -4 minecraft:coarse_dirt
setblock 1 240 0 minecraft:grass_block[snowy=false]
fill 1 240 1 3 240 2 minecraft:dirt_path
fill 1 240 2 2 240 2 minecraft:rooted_dirt
setblock 2 240 0 minecraft:dirt_path
setblock 2 240 -1 minecraft:podzol[snowy=false]
setblock 3 240 -1 minecraft:rooted_dirt
setblock 3 240 0 minecraft:grass_block[snowy=false]
setblock 4 240 -1 minecraft:podzol[snowy=false]
setblock 5 240 -1 minecraft:dirt_path
setblock 6 240 -1 minecraft:coarse_dirt
setblock 7 240 -1 minecraft:grass_block[snowy=false]
setblock 4 240 0 minecraft:coarse_dirt
fill 5 240 0 6 240 0 minecraft:grass_block[snowy=false]
setblock 7 240 0 minecraft:rooted_dirt
setblock 4 240 1 minecraft:dirt_path
fill 5 240 1 6 240 1 minecraft:podzol[snowy=false]
setblock 7 240 1 minecraft:grass_block[snowy=false]
setblock 4 240 2 minecraft:emerald_block
setblock 5 240 2 minecraft:dirt_path
fill 6 240 3 7 240 2 minecraft:rooted_dirt
setblock 7 240 2 minecraft:shroomlight
setblock 7 240 4 minecraft:coarse_dirt
fill 4 240 3 5 240 3 minecraft:grass_block
setblock 5 240 4 minecraft:grass_block[snowy=false]
setblock 4 240 4 minecraft:dirt_path
setblock 3 240 3 minecraft:coarse_dirt
setblock 2 240 3 minecraft:podzol[snowy=false]
setblock 1 240 3 minecraft:rooted_dirt
setblock 1 240 4 minecraft:coarse_dirt
setblock 0 240 4 minecraft:dirt_path
setblock 0 240 5 minecraft:grass_block[snowy=false]
setblock 1 240 5 minecraft:dirt_path
setblock 2 240 5 minecraft:grass_block[snowy=false]
setblock 3 240 5 minecraft:coarse_dirt
setblock 4 240 5 minecraft:rooted_dirt
setblock 3 240 4 minecraft:shroomlight
setblock 2 240 4 minecraft:rooted_dirt
fill 4 240 7 1 240 6 minecraft:rooted_dirt
setblock 2 240 6 minecraft:dirt_path
setblock 3 240 6 minecraft:coarse_dirt
setblock 5 240 6 minecraft:podzol[snowy=false]
setblock 5 240 7 minecraft:shroomlight
setblock 6 240 7 minecraft:coarse_dirt
setblock 7 240 6 minecraft:dirt_path
setblock 7 240 5 minecraft:grass_block[snowy=false]
setblock 6 240 4 minecraft:grass_block[snowy=false]
setblock 5 240 5 minecraft:grass_block[snowy=false]
setblock 6 240 6 minecraft:grass_block[snowy=false]
setblock 6 240 5 minecraft:grass_block[snowy=false]
setblock 2 240 8 minecraft:dirt_path
setblock 3 240 8 minecraft:grass_block[snowy=false]
setblock 4 240 8 minecraft:dirt_path
setblock 5 240 8 minecraft:dirt_path
setblock 2 240 9 minecraft:dirt_path
setblock 3 240 9 minecraft:grass_block[snowy=false]
fill 2 240 9 -4 240 -4 water replace air
setblock -5 240 3 minecraft:water
setblock 1 240 -5 minecraft:water
setblock -1 237 -5 air
setblock -1 238 -5 dirt
setblock -2 238 -4 minecraft:dirt
setblock -7 238 0 minecraft:dirt


# 14 floor last
setblock 3 241 9 minecraft:moss_carpet
setblock 4 241 7 minecraft:moss_carpet
setblock 6 241 7 minecraft:moss_carpet
setblock 4 241 6 minecraft:moss_carpet
setblock 7 241 6 minecraft:moss_carpet
setblock 5 241 4 minecraft:moss_carpet
setblock 3 241 4 minecraft:moss_carpet
setblock 1 241 6 minecraft:moss_carpet
setblock 1 241 7 minecraft:moss_carpet
setblock -1 241 7 minecraft:moss_carpet
setblock -3 241 7 minecraft:moss_carpet
setblock -3 241 9 minecraft:moss_carpet
setblock -5 241 5 minecraft:moss_carpet
setblock -5 241 4 minecraft:moss_carpet
setblock -7 241 2 minecraft:moss_carpet
setblock -5 241 2 minecraft:moss_carpet
setblock -5 241 0 minecraft:moss_carpet
setblock -3 241 -1 minecraft:moss_carpet
setblock -2 241 -2 minecraft:moss_carpet
setblock -1 241 -3 minecraft:moss_carpet
setblock 0 241 -5 minecraft:moss_carpet
setblock -1 241 -5 minecraft:moss_carpet
setblock -7 241 -1 minecraft:moss_carpet
setblock 2 241 2 minecraft:moss_carpet
setblock 1 241 1 minecraft:moss_carpet
setblock 2 241 1 minecraft:moss_carpet
setblock 3 241 1 minecraft:moss_carpet
setblock 7 241 1 minecraft:moss_carpet
setblock 7 241 -1 minecraft:moss_carpet
setblock 5 241 -2 minecraft:moss_carpet
setblock -4 242 9 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -4 242 8 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock -5 242 8 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -5 242 7 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock -6 242 7 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock -6 242 6 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -7 242 6 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock -7 241 5 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
fill -7 241 6 -5 241 6 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
fill -7 241 7 -5 241 7 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
fill -6 241 8 -3 241 8 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -4 241 7 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -5 241 9 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -4 241 9 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock 5 241 5 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 6 241 6 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 7 241 5 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock 6 242 5 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
fill 6 241 5 6 241 3 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock 6 241 -3 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock 5 241 -3 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 5 241 -4 4 241 -4 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
fill 5 242 -4 4 242 -4 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock 4 242 -5 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 4 241 -5 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 3 241 -4 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock 3 241 -5 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock 3 242 -5 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock 2 241 -5 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
fill -5 242 -2 -5 242 -1 spruce_leaves[distance=7,persistent=true,waterlogged=false]
fill -4 241 -2 -6 241 -2 spruce_leaves[distance=7,persistent=true,waterlogged=false]
fill -5 241 -3 -4 242 -3 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -5 242 -3 air
setblock -5 241 -1 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -6 242 -1 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock -6 241 -1 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
fill -6 241 0 -7 242 0 minecraft:spruce_leaves[distance=7,persistent=true,waterlogged=false]
setblock -7 242 0 air
setblock -7 241 1 minecraft:dark_oak_leaves[distance=7,persistent=true,waterlogged=false]
setblock 4 239 2 minecraft:repeating_command_block[conditional=false,facing=south]{Command:"tp @a[tag=!global.ignore,distance=40..] 4.60 241.00 2.52 90 0",CustomName:'{"text":"@"}',LastExecution:3174306L,LastOutput:'{"extra":[{"color":"red","extra":[{"translate":"argument.entity.notfound.entity"}],"text":""}],"text":"[12:56:45] "}',SuccessCount:0,TrackOutput:1b,UpdateLastExecution:1b,auto:1b,conditionMet:1b,powered:0b}
setblock 4 239 3 minecraft:chain_command_block[conditional=false,facing=south]{Command:"gamemode adventure @a[gamemode=survival,distance=0..]",CustomName:'{"text":"@"}',LastExecution:11489L,LastOutput:'{"extra":[{"color":"red","extra":[{"translate":"argument.entity.notfound.player"}],"text":""}],"text":"[21:56:38] "}',SuccessCount:0,TrackOutput:1b,UpdateLastExecution:1b,auto:1b,conditionMet:1b,powered:0b}
setblock 4 239 4 minecraft:chain_command_block[conditional=false,facing=south]{Command:"scoreboard players set @a[distance=..40] pvp 1",CustomName:'{"text":"@"}',LastExecution:21344L,LastOutput:'{"extra":[{"translate":"commands.scoreboard.players.set.success.single","with":[{"translate":"chat.square_brackets","with":[{"hoverEvent":{"action":"show_text","contents":{"text":"pvp"}},"text":"pvp"}]},"Manolo006","1"]}],"text":"[22:55:19] "}',SuccessCount:1,TrackOutput:1b,UpdateLastExecution:1b,auto:1b,conditionMet:1b,powered:0b}
setblock 4 239 5 minecraft:chain_command_block[conditional=false,facing=south]{Command:"function uhc:nopvp",CustomName:'{"text":"@"}',LastExecution:21434L,LastOutput:'{"extra":[{"translate":"commands.function.success.single","with":["9","uhc:nopvp"]}],"text":"[22:55:35] "}',SuccessCount:1,TrackOutput:1b,UpdateLastExecution:1b,auto:1b,conditionMet:1b,powered:0b}
