# barrier flow
setblock 1 228 11 minecraft:barrier
setblock 2 228 10 minecraft:barrier
setblock 1 228 9 minecraft:barrier
setblock 0 228 10 minecraft:barrier
setblock 1 227 10 minecraft:barrier
setblock 1 228 -5 minecraft:barrier
setblock 0 228 -6 minecraft:barrier
setblock 2 228 -6 minecraft:barrier
setblock 1 228 -7 minecraft:barrier
setblock 1 227 -6 minecraft:barrier

# 1 floor
setblock -1 227 1 minecraft:dirt

# 2 floor
setblock -1 228 0 minecraft:dirt
setblock -2 228 1 minecraft:dirt
setblock -1 228 2 minecraft:dirt
setblock 0 228 1 minecraft:dirt

# 3 floor
setblock -2 229 2 minecraft:dirt
setblock -2 229 1 minecraft:dirt
setblock -2 229 0 minecraft:dirt
setblock -1 229 -1 minecraft:dirt
setblock -1 229 2 minecraft:dirt
setblock 0 229 2 minecraft:dirt
setblock 1 229 1 minecraft:dirt
setblock 0 229 0 minecraft:shroomlight

# 4 floor
fill 1 230 -1 -2 230 3 dirt
setblock 1 230 -1 minecraft:air
setblock -2 230 -1 minecraft:air
fill 0 230 2 -1 230 0 air
setblock -3 230 1 minecraft:dirt
fill 2 231 4 -3 231 -1 dirt
setblock -3 231 4 minecraft:air
fill -3 231 -1 -3 231 0 air
setblock 2 231 -1 air
setblock -3 231 0 minecraft:shroomlight
setblock 0 231 4 minecraft:shroomlight
fill -2 231 3 1 231 0 air

# 5 floor
fill 3 232 -2 -4 232 5 dirt
fill -4 232 1 -4 232 -2 air
setblock -3 232 -1 minecraft:air
fill -3 232 -2 -2 232 -2 air
fill 2 232 -2 3 232 -2 air
setblock 3 232 -1 air
fill 1 232 5 3 232 5 air
setblock 3 232 4 air
setblock -4 232 4 air
fill -3 232 5 -4 232 5 air
setblock 3 232 3 minecraft:shroomlight

# 6 floor
fill 4 233 6 -5 233 -3 dirt
fill 3 233 5 4 233 6 air
fill 4 233 0 4 233 -2 air
fill 4 233 -3 1 233 -3 air
fill -5 233 -3 -5 233 6 air
fill -2 233 -2 -4 233 -3 air
setblock -4 233 -1 air
setblock -1 233 -3 air
fill 1 233 -3 4 233 -3 air
fill 4 233 -2 4 233 0 air
fill -2 233 6 -4 233 6 air
setblock -1 233 6 minecraft:shroomlight

# 7 floor
fill 5 234 -3 -5 234 6 dirt
fill -4 234 6 -5 234 6 air
setblock -5 234 5 minecraft:air
fill -5 234 0 -5 234 -3 air
fill -4 234 -3 -3 234 -2 air
setblock -2 234 -3 minecraft:air
fill 5 234 -1 4 234 -3 air
setblock 3 234 -3 minecraft:air
setblock 5 234 0 minecraft:air
fill 5 234 4 5 234 6 air
setblock 4 234 6 minecraft:air
setblock -5 234 2 minecraft:shroomlight
setblock 5 234 2 minecraft:shroomlight

# 8 floor
fill -6 235 -4 5 235 7 dirt
fill 3 235 7 5 235 7 air
setblock 5 235 6 minecraft:air
fill -2 235 7 -6 235 7 air
setblock -5 235 6 minecraft:air
fill -6 235 6 -6 235 3 air
fill -6 235 1 -6 235 -4 air
fill -5 235 -2 -4 235 -4 air
setblock -5 235 -1 minecraft:air
fill -3 235 -3 -3 235 -4 air
fill -2 235 -4 -1 235 -4 air
fill 1 235 -4 5 235 -4 air
fill 4 235 -3 5 235 -3 air
fill 5 235 -2 5 235 -1 air

# 9 floor
fill 6 236 7 -6 236 -5 dirt
fill -6 236 -5 -4 236 -3 air
fill -3 236 -4 -2 236 -5 air
setblock -1 236 -5 minecraft:air
setblock -5 236 -2 minecraft:air
fill -6 236 -2 -6 236 0 air
fill -6 236 7 -5 236 6 air
setblock -4 236 7 minecraft:air
setblock -6 236 5 minecraft:air
setblock 5 236 7 minecraft:air
fill 6 236 7 6 236 4 air
fill 2 236 -5 6 236 -4 air
setblock 5 236 -3 minecraft:air
fill 6 236 -3 6 236 0 air
fill 2 236 7 -1 236 7 rooted_dirt
setblock -2 236 -3 rooted_dirt
setblock 2 236 -4 minecraft:shroomlight

# 10 floor
fill 7 237 8 -7 237 -5 dirt
fill -5 237 7 -7 237 8 air
fill -7 237 6 -7 237 5 air
setblock -4 237 8 minecraft:air
fill -2 237 -4 -7 237 -5 air
fill -6 237 -3 -7 237 -2 air
fill -7 237 0 -7 237 -1 air
setblock -5 237 -3 minecraft:air
fill 7 237 1 7 237 -5 air
fill 6 237 -2 6 237 -5 air
fill 3 237 -5 5 237 -5 air
fill 5 237 -4 4 237 -4 air
fill 4 237 8 7 237 8 air
fill 7 237 7 7 237 3 air
fill 6 237 6 6 237 7 air
setblock 5 237 7 minecraft:air
setblock -2 237 -3 rooted_dirt
setblock -1 238 -5 minecraft:dirt
setblock -2 238 -4 minecraft:dirt