# Countdown 1
title @a title ["",{"text":"Inizio in: ","color":"gold"},{"text":"1"}]
tellraw @a ["",{"text":"Inizio in: ","color":"gold"},{"text":"1"}]
execute at @a run playsound minecraft:block.note_block.hat master @a ~ ~ ~ 10
schedule function uhc:countdown/cd_0 1s