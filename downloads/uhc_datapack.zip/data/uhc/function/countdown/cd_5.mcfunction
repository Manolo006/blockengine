# Countdown 5
title @a title ["",{"text":"Inizio in: ","color":"gold"},{"text":"5"}]
tellraw @a ["",{"text":"Inizio in: ","color":"gold"},{"text":"5"}]
execute at @a run playsound minecraft:block.note_block.hat master @a ~ ~ ~ 10
schedule function uhc:countdown/cd_4 1s