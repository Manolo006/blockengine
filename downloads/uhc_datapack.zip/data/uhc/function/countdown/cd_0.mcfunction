# Countdown 0
title @a title ["",{"text":"Via!","color":"gold"}]
tellraw @a {"text":"UHC Iniziata!","color":"gold"}
execute at @a run playsound minecraft:block.note_block.bell master @a ~ ~ ~ 10
function uhc:start