# Countdown 2
title @a title ["",{"text":"Inizio in: ","color":"gold"},{"text":"2"}]
tellraw @a ["",{"text":"Inizio in: ","color":"gold"},{"text":"2"}]
execute at @a run playsound minecraft:block.note_block.hat master @a ~ ~ ~ 10
schedule function uhc:countdown/cd_1 1s