# Countdown 4
title @a title ["",{"text":"Inizio in: ","color":"gold"},{"text":"4"}]
tellraw @a ["",{"text":"Inizio in: ","color":"gold"},{"text":"4"}]
execute at @a run playsound minecraft:block.note_block.hat master @a ~ ~ ~ 10
schedule function uhc:countdown/cd_3 1s