# Countdown 3
title @a title ["",{"text":"Inizio in: ","color":"gold"},{"text":"3"}]
tellraw @a ["",{"text":"Inizio in: ","color":"gold"},{"text":"3"}]
execute at @a run playsound minecraft:block.note_block.hat master @a ~ ~ ~ 10
schedule function uhc:countdown/cd_2 1s