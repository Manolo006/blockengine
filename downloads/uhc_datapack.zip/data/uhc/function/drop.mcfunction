summon chicken ~ ~35 ~ {Silent:1b,Invulnerable:1b,Team:"drop",Passengers:[{id:"minecraft:falling_block",BlockState:{Name:"minecraft:barrel",Properties:{facing:"up"}},TileEntityData:{LootTable:"uhc:drop"},Glowing:1b,Time:1}],active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:199980,show_particles:0b,show_icon:0b,ambient:0b}]}
data modify storage drop macro set value {"maxRange":0}
scoreboard players operation wbSize uhc.trigger -= -10 uhc.trigger
scoreboard players operation wbSize uhc.trigger /= 2 uhc.trigger
execute store result storage drop macro.maxRange int 1 run scoreboard players get wbSize uhc.trigger
function uhc:drop_tp with storage drop macro