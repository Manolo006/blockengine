# no pvp
execute as @a[team=uhc.aqua,scores={pvp=1}] at @s if entity @e[type=minecraft:player,distance=0.2..4.5,team=!uhc.aqua] run attribute @s minecraft:attack_damage base set -100
execute as @a[team=uhc.black,scores={pvp=1}] at @s if entity @e[type=minecraft:player,distance=0.2..4.5,team=!uhc.black] run attribute @s minecraft:attack_damage base set -100
execute as @a[team=uhc.darkBlue,scores={pvp=1}] at @s if entity @e[type=minecraft:player,distance=0.2..4.5,team=!uhc.darkBlue] run attribute @s minecraft:attack_damage base set -100
execute as @a[team=uhc.darkRed,scores={pvp=1}] at @s if entity @e[type=minecraft:player,distance=0.2..4.5,team=!uhc.darkRed] run attribute @s minecraft:attack_damage base set -100
execute as @a[team=uhc.lightPurple,scores={pvp=1}] at @s if entity @e[type=minecraft:player,distance=0.2..4.5,team=!uhc.lightPurple] run attribute @s minecraft:attack_damage base set -100
execute as @a[team=uhc.yellow,scores={pvp=1}] at @s if entity @e[type=minecraft:player,distance=0.2..4.5,team=!uhc.yellow] run attribute @s minecraft:attack_damage base set -100
execute as @a[team=uhc.darkPurple,scores={pvp=1}] at @s if entity @e[type=minecraft:player,distance=0.2..4.5,team=!uhc.darkPurple] run attribute @s minecraft:attack_damage base set -100
execute as @a[scores={pvp=1}] at @s if entity @e[type=minecraft:player,distance=4.5..] run attribute @s minecraft:attack_damage base set 1
execute as @a[scores={pvp=0}] at @s if entity @e[type=minecraft:player,distance=4.5..] run attribute @s minecraft:attack_damage base set 1