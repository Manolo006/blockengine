$spreadplayers 0 0 0 $(maxRange) true @e[team=drop]
execute as @e[team=drop,limit=1] at @s run tp @s ~ ~50 ~
execute as @e[team=drop] store result score x test run data get entity @s Pos[0] 1
execute as @e[team=drop] store result score z test run data get entity @s Pos[2] 1
tellraw @a ["",{"text":"Il drop è caduto a coordinate: "},{"score":{"name":"x","objective":"test"},"color":"gold","bold":true},{"text":" ","color":"gold"},{"score":{"name":"z","objective":"test"},"color":"gold","bold":true}]