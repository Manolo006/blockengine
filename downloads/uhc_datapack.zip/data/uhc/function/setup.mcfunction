### Gamerules / World Prep
gamerule naturalRegeneration true
gamerule spawnRadius 0
gamerule commandBlockOutput false
gamerule logAdminCommands false
gamerule doDaylightCycle true
gamerule doWeatherCycle true
gamerule fallDamage false
gamerule drowningDamage false
gamerule doImmediateRespawn true
time set day

### spawn
team leave @a
scoreboard players set @a pvp 1
gamemode adventure @a
fill -9 255 11 9 226 -7 air
kill @e[tag=uhc.armor_stand.gabbia]
#summon armor_stand 1.20 240.44 2.50 {CustomNameVisible:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,ShowArms:0b,Small:0b,Marker:0b,Invisible:1b,NoBasePlate:1b,Tags:["uhc.armor_stand.gabbia"],DisabledSlots:4144959,ArmorItems:[{},{},{id:"minecraft:golden_apple",Count:1b},{id:"minecraft:player_head",Count:1b,tag:{SkullOwner:"Manolo006"}}],CustomName:'{"text":"UHC Negri","color":"gold"}'}
tp @e[tag=uhc.armor_stand.gabbia,type=armor_stand] 1.20 240.44 2.50 -90 0
execute as @a at @a run kill @e[type=item,distance=..50]
tp @a 4 241 2 90 0
setworldspawn 4 241 2


### Teams
team add uhc.aqua
team add uhc.green
team add uhc.blue
team add uhc.lightPurple
team add uhc.gold
team add uhc.red
team add uhc.yellow
team add uhc.darkAqua
team add uhc.darkBlue
team add uhc.darkGray
team add uhc.darkGreen
team add uhc.darkPurple
team add uhc.darkRed
team add uhc.gray
team add uhc.black
team add uhc.white
team add drop

# Colour Teams
team modify uhc.aqua color aqua
team modify uhc.green color green
team modify uhc.blue color blue
team modify uhc.lightPurple color light_purple
team modify uhc.gold color gold
team modify uhc.red color red
team modify uhc.yellow color yellow
team modify uhc.darkAqua color dark_aqua
team modify uhc.darkBlue color dark_blue
team modify uhc.darkGray color dark_gray
team modify uhc.darkGreen color dark_green
team modify uhc.darkPurple color dark_purple
team modify uhc.darkRed color dark_red
team modify uhc.gray color gray
team modify uhc.black color black
team modify uhc.white color white

# Friendly Fire Off
team modify uhc.aqua friendlyFire false
team modify uhc.green friendlyFire false
team modify uhc.blue friendlyFire false
team modify uhc.lightPurple friendlyFire false
team modify uhc.gold friendlyFire false
team modify uhc.red friendlyFire false
team modify uhc.yellow friendlyFire false
team modify uhc.darkAqua friendlyFire false
team modify uhc.darkBlue friendlyFire false
team modify uhc.darkGray friendlyFire false
team modify uhc.darkGreen friendlyFire false
team modify uhc.darkPurple friendlyFire false
team modify uhc.darkRed friendlyFire false
team modify uhc.gray friendlyFire false
team modify uhc.black friendlyFire false
team modify uhc.white friendlyFire false

### Scoreboards
## Scoreboard Adding
# Health
scoreboard objectives add uhc.health health "Health"

# General
scoreboard objectives add uhc.trigger dummy
scoreboard objectives add uhc.info dummy {"text":"Game Stats","color":"gold"}
scoreboard objectives add uhc.deathCount deathCount
scoreboard objectives add uhc.ticks dummy
scoreboard objectives add wbDisplay trigger
scoreboard objectives add kills dummy
scoreboard objectives add test dummy


# Auto Smelt
scoreboard objectives add item_age dummy
scoreboard objectives add uhc.c.rabbitK minecraft.killed:minecraft.rabbit
scoreboard objectives add uhc.c.potatoM minecraft.mined:minecraft.potatoes
scoreboard objectives add uhc.c.fishCatch minecraft.custom:minecraft.fish_caught
scoreboard objectives add uhc.c.pigK minecraft.killed:minecraft.pig
scoreboard objectives add uhc.c.codK minecraft.killed:minecraft.cod
scoreboard objectives add uhc.c.salmonK minecraft.killed:minecraft.salmon
scoreboard objectives add uhc.c.chickenK minecraft.killed:minecraft.chicken
scoreboard objectives add uhc.c.cowK minecraft.killed:minecraft.cow
scoreboard objectives add uhc.c.sheepK minecraft.killed:minecraft.sheep
scoreboard objectives add uhc.c.kelpM minecraft.mined:minecraft.kelp

# Golden Apple Death
scoreboard objectives add uhc.c.killCount minecraft.custom:minecraft.player_kills
scoreboard objectives add uhc.e.honey minecraft.used:minecraft.enchanted_golden_apple

# Always Flint
scoreboard objectives add uhc.c.gravelM minecraft.mined:minecraft.gravel

# Drowned Trident
scoreboard objectives add uhc.c.drownedK minecraft.killed:minecraft.drowned

# Team Check
scoreboard objectives add uhc.tm.check dummy

# World Border
scoreboard objectives add uhc.wb.display trigger


## Scoreboard Modifying
# Health
scoreboard objectives setdisplay list uhc.health

# General
scoreboard players set start uhc.trigger 0
scoreboard players set time uhc.trigger 0
scoreboard players set ticks uhc.ticks 0
scoreboard players set seconds uhc.info 0
scoreboard players set minutes uhc.info 0
scoreboard players set AlivePlayers uhc.info 0
scoreboard players set DeadPlayers uhc.info 0



# Customisation Trigger
scoreboard players set always_flint uhc.trigger 0
scoreboard players set auto_smelt uhc.trigger 0
scoreboard players set golden_apple uhc.trigger 0
scoreboard players set more_hearts uhc.trigger 0
scoreboard players set delete_stones uhc.trigger 0
scoreboard players set no_ai uhc.trigger 0
scoreboard players set drowned_trident uhc.trigger 0
scoreboard players set no_nether uhc.trigger 0
scoreboard players set time_msg uhc.trigger 0
scoreboard players set drop uhc.trigger 0

# Gamemodes Trigger
scoreboard players set hastey uhc.trigger 0

# World Border
scoreboard players set wb_shrinking uhc.trigger 1
scoreboard players set wb_1k uhc.trigger 0
scoreboard players set wb_3k uhc.trigger 0

# Team Size
scoreboard objectives add uhc.teamsize dummy
scoreboard players set team_1 uhc.teamsize 0
scoreboard players set team_2 uhc.teamsize 0
scoreboard players set team_3 uhc.teamsize 0
scoreboard players set team_4 uhc.teamsize 0
scoreboard players set team_5 uhc.teamsize 0

# nopvp
scoreboard objectives add pvp dummy

### Comformation Message
tellraw @a[tag=!global.ignore] {"text":"Setup Complete","color":"gold"}

#spawn
function uhc:spawn/spawn
function uhc:spawn/spawn2
function uhc:spawn/spawn3