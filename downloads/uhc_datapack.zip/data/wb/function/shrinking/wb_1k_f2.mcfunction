worldborder add -300 1200
schedule function wb:shrinking/wb_1k_f3 1800s
tellraw @a {"text":"IL BORDO SI STA RESTRINGENDO...","bold":true,"color":"dark_red","hover_event":{"action":"show_text","value":"400X400 IN 20 MINUTI"}}
title @a subtitle {"text":"400X400 IN 20 MINUTI","bold":true,"color":"dark_red"}
title @a title {"text":"IL BORDO SI STA RESTRINGENDO...","bold":true,"color":"dark_red"}
function wb:zone_reduce
schedule function wb:zone_stay 1200s