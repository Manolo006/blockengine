worldborder add -350 600
tellraw @a {"text":"IL BORDO SI STA RESTRINGENDO...","bold":true,"color":"dark_red","hover_event":{"action":"show_text","value":"50X50 IN 10 MINUTI"}}
title @a subtitle {"text":"50X50 IN 10 MINUTI","bold":true,"color":"dark_red"}
title @a title {"text":"IL BORDO SI STA RESTRINGENDO...","bold":true,"color":"dark_red"}
function wb:zone_reduce
schedule function wb:zone_stay 600s