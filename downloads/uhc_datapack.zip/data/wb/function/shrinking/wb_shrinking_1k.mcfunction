worldborder set 1000
schedule function wb:shrinking/wb_1k_f1 600s
scoreboard players set @a pvp 1
execute as @a at @a run kill @e[type=item,distance=..50]
spreadplayers ~ ~ 225 450 true @a
gamerule fallDamage true
gamerule drowningDamage true
tellraw @a ["",{"text":"IL ","bold":true},{"text":"PVP","bold":true,"color":"gray"},{"text":" È","bold":true},{"text":" DISABILITATO","bold":true,"color":"red"},{"text":" PER ","bold":true},{"text":"10","bold":true,"color":"gray"},{"text":" MINUTI","bold":true}]