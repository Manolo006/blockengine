worldborder add -950 3600
schedule function wb:shrinking/wb_3k_f2 2700s
scoreboard players set @a pvp 0
tellraw @a {"text":"IL BORDO SI STA RESTRINGENDO...","bold":true,"color":"dark_red","hover_event":{"action":"show_text","value":"700X700 IN 20 MINUTI"}}
title @a subtitle {"text":"700X700 IN 20 MINUTI","bold":true,"color":"dark_red"}
title @a title {"text":"IL BORDO SI STA RESTRINGENDO...","bold":true,"color":"dark_red"}
tellraw @a ["",{"text":"IL ","bold":true},{"text":"PVP","bold":true,"color":"gray"},{"text":" È","bold":true},{"text":" ABILITATO","bold":true,"color":"green"}]
function wb:zone_reduce
schedule function wb:zone_stay 3600s