worldborder add -950 3600
schedule function wb:shrinking/wb_3k_f3 5400s
tellraw @a {"text":"IL BORDO SI STA RESTRINGENDO...","bold":true,"color":"dark_red","hover_event":{"action":"show_text","value":"400X400 IN 20 MINUTI"}}
title @a subtitle {"text":"400X400 IN 20 MINUTI","bold":true,"color":"dark_red"}
title @a title {"text":"IL BORDO SI STA RESTRINGENDO...","bold":true,"color":"dark_red"}
function wb:zone_reduce
schedule function wb:zone_stay 3600s