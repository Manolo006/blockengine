execute at @a run playsound minecraft:block.beacon.deactivate master @a
