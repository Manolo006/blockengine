execute at @a run playsound minecraft:block.beacon.activate master @a
schedule function uhc:drop 120s