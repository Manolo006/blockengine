scoreboard players set wb_1k uhc.trigger 0
scoreboard players set wb_3k uhc.trigger 1
scoreboard players set wb_5k uhc.trigger 0
worldborder set 3000