### Remove Scoreboards
scoreboard objectives remove item_age
scoreboard objectives remove pvp
scoreboard objectives remove uhc.c.chickenK
scoreboard objectives remove uhc.c.codK
scoreboard objectives remove uhc.c.cowK
scoreboard objectives remove uhc.c.drownedK
scoreboard objectives remove uhc.c.fishCatch
scoreboard objectives remove uhc.c.gravelM
scoreboard objectives remove uhc.c.kelpM
scoreboard objectives remove uhc.c.killCount
scoreboard objectives remove uhc.c.pigK
scoreboard objectives remove uhc.c.potatoM
scoreboard objectives remove uhc.c.rabbitK
scoreboard objectives remove uhc.c.salmonK
scoreboard objectives remove uhc.c.sheepK
scoreboard objectives remove uhc.deathCount
scoreboard objectives remove uhc.health
scoreboard objectives remove uhc.info
scoreboard objectives remove uhc.teamsize
scoreboard objectives remove uhc.tm.check
scoreboard objectives remove uhc.trigger
scoreboard objectives remove uhc.wb.display
scoreboard objectives remove uhc.e.honey


### Remove Teams
team remove uhc.aqua
team remove uhc.black
team remove uhc.darkBlue
team remove uhc.darkGreen
team remove uhc.darkPurple
team remove uhc.darkRed
team remove uhc.lightPurple
team remove uhc.yellow


### World
worldborder set 9999999
fill -9 255 11 9 226 -7 air
execute as @e[tag=uhc.armor_stand.gabbia] at @a run kill @e[type=item,distance=..50]
kill @e[tag=uhc.armor_stand.gabbia]


### Players
clear @a

### confirm
tellraw @a "il datapack è stato disinstallato correttamente per riabilitarlo semplicemente fare /reload"