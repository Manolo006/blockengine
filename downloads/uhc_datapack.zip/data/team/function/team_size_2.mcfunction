# Team Size 2 Randomiser Function
tellraw @a ["",{"text":"Team Size: ","color":"gold"},{"text":"2","color":"white"}]
team leave @a
team join uhc.aqua @r[limit=2]
team join uhc.green @r[limit=2]
team join uhc.blue @r[limit=2]
team join uhc.lightPurple @r[limit=2]
team join uhc.gold @r[limit=2]
team join uhc.red @r[limit=2]
team join uhc.yellow @r[limit=2]
team join uhc.darkAqua @r[limit=2]
team join uhc.darkBlue @r[limit=2]
team join uhc.darkGray @r[limit=2]
team join uhc.darkGreen @r[limit=2]
team join uhc.darkPurple @r[limit=2]
team join uhc.darkRed @r[limit=2]
team join uhc.gray @r[limit=2]
team join uhc.black @r[limit=2]
team join uhc.white @r[limit=2]

scoreboard players set team_1 uhc.teamsize 0
scoreboard players set team_2 uhc.teamsize 0
scoreboard players set team_3 uhc.teamsize 0
scoreboard players set team_4 uhc.teamsize 0
scoreboard players set team_5 uhc.teamsize 0